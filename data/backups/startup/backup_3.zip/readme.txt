Backup time: 2024-10-17 at 15:57:55 UTC
ServerName: pragmaticos
Current server version:41.78
Current world version:195
World version in this backup is:195